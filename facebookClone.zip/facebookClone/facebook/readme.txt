Hello,

Greeting of the day!!

Below are the guidelines to use the facebook clone web page.

Open facebook.html with browser(Use chrome for best view)

Available functions:-

	Editable functions:
		-> Create the Post
			* Provide your input for post and click on Post button
		-> Edit the Post
			* Once the post is visible on the page, the user can edit using Edit Button in My Posts Section.
			* Once edit is completed click on button Done to commit the changes.
			* Users can see the updated post in the My Posts section.
		-> Delete the Post
			* User can Delete the Post using the Delete button in My Post section.

	Non-Editable functions:
		-> View Friend Requests
		-> View Friend Suggestions
		-> View Posts of Friends

Notes:
1. Users can see max one post only in My Posts section. Every Post action will replace the existing post if any.
2. For bootstrap I have referred to open source materials.

Regards
Mounika A
